<?php
		session_start();
		
		$postagem = $_POST['postagem'];
		$usuario = $_POST['usuario'];
		
		require('../classes/postagens.php');
		$postagens = new postagens();


		
		$postar = $postagens->cadastraPost($postagem,$usuario);	
		
?>